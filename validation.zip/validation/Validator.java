package extraction.validation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.StringTokenizer;

public class Validator {

	public static void main(String[] args) throws IOException {
	   
	   HashMap<Integer, Integer> colSize = new HashMap<Integer,Integer>();
	   colSize.put(1, 2);
	   colSize.put(2, 5);
	   HashMap<Integer, String> colType = new HashMap<Integer,String>();
	   colType.put(1, "integer");
	   colType.put(2, "varchar");
		
       FileReader metafile = new FileReader("E:\\selenium\\extraction_files\\rawdata.txt");
       BufferedReader br = new BufferedReader(metafile);
       File validfile = new File("E:\\selenium\\extraction_files\\validdata.txt");
       PrintWriter print = new PrintWriter(validfile); 
       FileWriter validdata = new FileWriter(validfile);
       String line, token;
       StringTokenizer st= null;
       int lineNumber=0;
       while((line=br.readLine())!=null)
       {
    	  lineNumber++;
    	  System.out.println(lineNumber);
    	  int count=1;
    	  st=new StringTokenizer(line, "\t");
    	  while(st.hasMoreTokens())
    	  {
    		  //System.out.println(colSize.get(count));
    		  int size = colSize.get(count);
    		  String type = colType.get(count);
    		  
    			  
    		  token=st.nextToken();
    		  if(token.length()<=size&& type.equalsIgnoreCase("varchar") || type.equalsIgnoreCase("date")) {
    			  //System.out.println(token);
    			  print.print("'"+token+"'\t");
    		  }
    		  else if(token.length()<=size&& type.equalsIgnoreCase("integer") || type.contains("number")|| type.contains("Number")){
    			  //System.out.println(token);
    			  print.print(token+"\t");
    		  }
    		  else {
    			  print.print("null\t");
    			  System.out.println("length exceeded at "+token+ " in Line "+lineNumber);
    		  }   			  
    		    
    		  count++;
    		  if(count>colSize.size()) {
    			  print.println();
    			  count=1;
    		  }
    	  }
       }
       br.close();
       metafile.close();
       print.close();
       validdata.close();
	}

}
